1. Referred Paper:
Erheng Zhong, Wei Fan, Jing Peng, Kun Zhang, Jiangtao Ren, Deepak Turaga, Olivier Verscheure, "Cross Domain Distribution Adaptation Kernel Mapping", 
Proceedings of the 15th ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, 2009. Under review.


2. General Code Format Description 
Main Function:
classify.KMapEnsemble
classify.KMapWeight

Parameters (3 parameters):
1) Maximum number of iterations.
2) Ratio between labeled and unlabeled targeted-domain data 
3) Name of data set. Three choices. (SyskillWebert, Reuters, 20News)

3. Examples
Invoke example:
java -Xmx768m -cp ./lib/weka.jar;./bin classify.KMapEnsemble 10 0.1 SyskillWebert
java -Xmx768m -cp ./lib/weka.jar;./bin classify.KMapWeight 10 0.1 SyskillWebert

Then the programe will run on the selected datasets. The classification accuracy will be written in the result recording file "res_KMapEnsemble.txt" and "res_KMapWeight.txt".

4. Contact method:
Erheng Zhong: sysu.zeh@gmail.com
Wei Fan: wei.fan@gmail.com 
